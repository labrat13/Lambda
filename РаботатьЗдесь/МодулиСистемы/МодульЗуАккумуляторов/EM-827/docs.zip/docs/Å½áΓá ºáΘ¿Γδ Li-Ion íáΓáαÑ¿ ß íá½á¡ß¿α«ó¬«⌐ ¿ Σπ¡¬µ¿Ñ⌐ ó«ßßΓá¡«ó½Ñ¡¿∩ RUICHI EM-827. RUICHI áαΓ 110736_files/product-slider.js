$(document).ready(function () {
    /*var galleryThumbs = new Swiper('.nav-slider', {
        spaceBetween: 10,
        slidesPerView: 4,
        loop: true,
        freeMode: true,
        loopedSlides: 5, //looped slides should be the same
        watchSlidesVisibility: true,
        watchSlidesProgress: true,
        spaceBetween: 12,
    });
    var galleryTop = new Swiper('.main-slider', {
        spaceBetween: 10,
        loop:true,
        loopedSlides: 5, //looped slides should be the same
        lazy: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        thumbs: {
            swiper: galleryThumbs,
        },
    });*/

    var galleryThumbs = new Swiper('.nav-slider', {
        slidesPerView: 6,
        loop: false,
        freeMode: true,
        watchSlidesVisibility: true,
        watchSlidesProgress: true,

        breakpoints: {
            350: {
                slidesPerView: 3,
            },
            768: {
                slidesPerView: 5,
            },
            991: {
                slidesPerView: 8,
            },
        }
    });
    var galleryTop = new Swiper('.main-slider', {
        speed: 600,
        spaceBetween: 10,
        loop:false,
        loopedSlides: 5, //looped slides should be the same
        lazy: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        thumbs: {
            swiper: galleryThumbs,
        },
    });

});


