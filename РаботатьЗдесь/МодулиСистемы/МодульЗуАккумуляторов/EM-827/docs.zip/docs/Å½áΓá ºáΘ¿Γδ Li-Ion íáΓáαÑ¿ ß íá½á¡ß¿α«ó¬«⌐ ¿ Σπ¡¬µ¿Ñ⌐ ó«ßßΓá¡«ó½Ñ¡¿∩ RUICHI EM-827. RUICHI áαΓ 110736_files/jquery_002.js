function IMCallMeAskMe_getQueryParam(name) {
  var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(window.location.href.split('#')[0]);
  if (results)
    return results[1];
  else
    return '';
}

function IMCallMeAskMe_collectParams(form) {
  var sendArray = form.serializeArray(),
    queryArray = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term']
  ;

  // Сохраняем UTM метки
  for (var cnt = 0; cnt < queryArray.length; cnt++) {
    sendArray.push({
      name: queryArray[cnt],
      value: 	IMCallMeAskMe_getQueryParam(queryArray[cnt])
    });
  }

  return sendArray;
}

function IMCallMeAskMe_formSubmit(container) {
  if (typeof($.fn.ajaxSubmit) !== 'function') {
    $.getScript('/catalog/view/javascript/jquery.form.js', function () {
      var tmpContainer = container;
      IMCallMeAskMe_formSubmit(tmpContainer);
    });
    return;
  }

  container.find('form').submit(function (e) {
    e.preventDefault();

    var jq = jQuery,
      form = jq(this),
      submit = form.find('button[type=submit]')
    ;

    container.find('.has-error').removeClass('has-error');

    form.ajaxSubmit({
      url: form.attr('action'),
      type: 'post',
      cache: false,
      beforeSubmit: function() {
        submit.button('loading');
      },
      complete: function() {
        submit.button('reset');
      },
      success: function(json) {
        container.find('.alert, .text-danger').remove();

        if (json['error']) {
          if (json['warning']) {
            form.prepend('<div class="alert alert-warning">' + json['error']['warning'] + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
          }

          for (i in json['messages']) {
            var element = container.find('input[name="' + i + '"], textarea[name="' + i + '"]');
            element.closest('.form-group').addClass('has-error');
          }

          if (json['email_send']) {
            var element = jq('<div class="alert alert-danger" role="alert"></div>');
            element.text(json['email_send']);
            form.prepend(element);
          }

          // Highlight any found errors
          jq('.text-danger').parent().addClass('has-error');
        }
        else {
          var status_complete = jQuery(
            '<div class="alert alert-success">'
            + json['complete']
            + '</div>'
          );
          status_complete.insertBefore(form.find('*:first'));
          container.find('#imcallask-form-container-popup').fadeOut(3000, function() {
            CheckModalExists(function () {
              jq(this).modal('hide');
            });
            form.find('.alert-success').remove();
          });//.modal('hide');
          gtag('event', 'zvonok');
        }
      },
      error: function(xhr, ajaxOptions, thrownError) {
        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
      }
    });

    /*
    jq.ajax({
      url: form.attr('action'),
      type: 'post',
      cache: false,
      data: IMCallMeAskMe_collectParams(form),
      dataType: 'json',
      beforeSend: function() {
        submit.button('loading');
      },
      complete: function() {
        submit.button('reset');
      },
      success: function(json) {
        container.find('.alert, .text-danger').remove();

        if (json['error']) {
          if (json['warning']) {
            form.prepend('<div class="alert alert-warning">' + json['error']['warning'] + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
          }

          for (i in json['messages']) {
            var element = container.find('input[name="' + i + '"], textarea[name="' + i + '"]');
            element.closest('.form-group').addClass('has-error');
          }

          if (json['email_send']) {
            var element = jq('<div class="alert alert-danger" role="alert"></div>');
            element.text(json['email_send']);
            form.prepend(element);
          }

          // Highlight any found errors
          jq('.text-danger').parent().addClass('has-error');
        }
        else {
          var status_complete = jQuery(
            '<div class="alert alert-success">'
            + json['complete']
            + '</div>'
          );
          status_complete.insertBefore(form.find('*:first'));
          container.find('#imcallask-form-container-popup').fadeOut(3000, function() {
            CheckModalExists(function () {
              jq(this).modal('hide');
            });
            form.find('.alert-success').remove();
          });//.modal('hide');
          gtag('event', 'zvonok');
        }
      },
      error: function(xhr, ajaxOptions, thrownError) {
        console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
      }
    });
    */

    return false;
  });
}

function IMCallMeAskMe_formPopup () {
  var jq = jQuery
  ;
  if (jq('.imcallask-form-container').length > 0) {
    CheckModalExists(function () {
      jq('.imcallask-form-container #imcallask-form-container-popup').modal();
    });
    /*jq('.imcallask-form-container #imcallask-form-container-popup').fancybox().trigger('click');*/
  }
  else {
    var container = jq('<div class="imcallask-form-container">')
    ;

    jQuery('body').append(container);

      jq.ajax('index.php?route=extension/module/IMCallMeAskMe/getPopup',
        {
        success: function (html) {
          var hidden = jq('<input type="hidden" name="url" value="">');

          container.html(html);

          container.find('form').append(hidden);

          hidden.val(encodeURIComponent(window.location));

          CheckModalExists(function () {
            container.find('#imcallask-form-container-popup').modal();
          });
          /*container.find('#imcallask-form-container-popup').fancybox().trigger('click');*/
          IMCallMeAskMe_formSubmit(container);
        }
      });
  }
}

function IMCallMeAskMe_formPopupMail () {
  var jq = jQuery;

    var container = jq('<div class="imcallask-form-container">');

    jQuery('body').append(container);

    jq.ajax('index.php?route=extension/module/IMCallMeAskMe/getPopupMail',
      {
        success: function (html) {
          var hidden = jq('<input type="hidden" name="url" value="">');

          container.html(html);

          container.find('form').append(hidden);

          hidden.val(encodeURIComponent(window.location));

          CheckModalExists(function () {
            container.find('#imcallask-form-container-popup').modal();
          });
          /*container.find('#imcallask-form-container-popup').fancybox().trigger('click');*/
          IMCallMeAskMe_formSubmit(container);
        }
      });

}



function IMCallMeAskMe_createButton() {
  var jq = jQuery,
    btn = jq('<a href="#" class="imcallask-btn-mini"><div class="imcallask-btn-mini-phone"></div></a>')
  ;

  jq('body').append(btn);

  btn.click(function (e) {
    e.preventDefault();
    IMCallMeAskMe_formPopup();
    return false;
  });
}

function CheckModalExists (callback) {
  if (typeof $.fn.modal === 'function') {
    return callback();
  }
  $.getScript('/catalog/view/javascript/bootstrap/js/bootstrap.min.js', callback);
}

jQuery(function () {
  var jq = jQuery
  ;
  // Если пользователь сам установил
  if (jq('.imcallask-click').length > 0) {
    jq('.imcallask-click').click(function (e) {
      e.preventDefault();
      IMCallMeAskMe_formPopup();
      return false;
    });
  }
  else {
    IMCallMeAskMe_createButton();
  }
});

jQuery(function () {
  var jq = jQuery
  ;
  // Если пользователь сам установил
  if (jq('.imcallask-click-mail').length > 0) {
    jq('.imcallask-click-mail').click(function (e) {
      e.preventDefault();
      IMCallMeAskMe_formPopupMail();
      return false;
    });
  }
  else {
    IMCallMeAskMe_createButton();
  }
});
