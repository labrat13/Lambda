/* Функуия табов своя собственная реализация для табов на странице продукта */
function tabs_roman(id_tab) {
  var hasActiveTabs = ($(id_tab + ' ul.b-tabs__list li.active').length > 0);
  $(id_tab + ' .b-tabs__content:not(.active)').css({'display':'none'});
  //$('.b-tabs__item:not(.active)').addClass('border-not_active');
  if (!hasActiveTabs) {
    //$('.b-tabs__item:not(.active)').addClass('border-not_active');
    /* Скрываем все табы */
    //при условии, что все вкладки неактивны
    $(id_tab + ' ul.b-tabs__list li').removeClass('active');
    $(id_tab + ' > div').removeClass('active');
    /* показываем толкьо первый таб */
    $(id_tab + ' .b-tabs__content').first().css({'display':'block'});
    $(id_tab + ' ul.b-tabs__list li').first().addClass('active');
    $(id_tab + ' > div').first().addClass('active');


  }



  /* Тоже самое только с классами */
  /*$('#b-tabs .b-tabs__content').addClass('hidden');
  $('#b-tabs .b-tabs__content').first().removeClass('hidden');*/


  $(document).on('click', id_tab + ' ul.b-tabs__list li', function (event) {
    event.preventDefault(); /* Запрещаем переход по ссылке */
    var act_tab = $(this).children('a').attr('href'); /* Получаем href таба */
    $(id_tab + ' .b-tabs__content').css({'display':'none'}); /* Скрываем все табы */
    $(id_tab + ' ul.b-tabs__list li').removeClass('active');
    $(id_tab + ' .b-tabs__content').removeClass('active');

    $(act_tab).css({'display':'block'}); /* Показываем 1 таб, у которого id = href */
    $(this).addClass('active');
    //$(this).removeClass('border-not_active');
    $(act_tab).addClass('active');
    //$(id_tab + ' ul.b-tabs__list li:not(.active)').css({'border-bottom':'1px solid #C4C4C4'});
    /* Тоже самое только с классами */
    /*$('#b-tabs .b-tabs__content').addClass('hidden');
    $(act_tab).removeClass('hidden');*/

  });
}

function tabs_class_roman(id_tab) {

  /* Скрываем все табы */
  $('#b-tabs .b-tabs__content').addClass('hidden');
  /* показываем толкьо первый таб */
  $('#b-tabs .b-tabs__content').first().removeClass('hidden');


  $(document).on('click', id_tab + ' ul.b-tabs__list li', function (event) {
    event.preventDefault(); /* Запрещаем переход по ссылке */
    var act_tab = $(this).children('a').attr('href'); /* Получаем href таба */

    /* Тоже самое только с классами */
    $('#b-tabs .b-tabs__content').addClass('hidden'); /* Скрываем все табы */
    $(act_tab).removeClass('hidden'); /* Показываем 1 таб, у которого id = href */

  });
}


//
//
//



/* Функуия табов своя собственная реализация для табов на странице сравнения*/
function tabs_roman_compare(id_tab) {
  /* Скрываем все табы */
  $(id_tab + ' .b-tabs__content-wrap').css({'display':'none'});
  $(id_tab + ' ul.b-tabs__list li').removeClass('active');
  $(id_tab + ' .b-tabs__content-wrap').removeClass('active');
  /* показываем толкьо первый таб */
  $(id_tab + ' .b-tabs__content-wrap').first().css({'display':'grid'});
  $(id_tab + ' ul.b-tabs__list li').first().addClass('active');
  $(id_tab + ' .b-tabs__content-wrap').first().addClass('active');

  /* Тоже самое только с классами */
  /*$('#b-tabs .b-tabs__content').addClass('hidden');
  $('#b-tabs .b-tabs__content').first().removeClass('hidden');*/


  $(document).on('click', id_tab + ' ul.b-tabs__list li', function (event) {
    event.preventDefault(); /* Запрещаем переход по ссылке */
    var act_tab = $(this).children('a').attr('href'); /* Получаем href таба */
    $(id_tab + ' .b-tabs__content-wrap').css({'display':'none'}); /* Скрываем все табы */
    $(id_tab + ' ul.b-tabs__list li').removeClass('active');
    $(id_tab + ' .b-tabs__content-wrap').removeClass('active');
    $(act_tab).css({'display':'block'}); /* Показываем 1 таб, у которого id = href */
    $(this).addClass('active');
    $(act_tab).addClass('active');

    /* Тоже самое только с классами */
    /*$('#b-tabs .b-tabs__content').addClass('hidden');
    $(act_tab).removeClass('hidden');*/

  });
}

// function tabs_class_roman_copmare(id_tab) {

// 	/* Скрываем все табы */
// 	$('#b-tabs .b-tabs__content').addClass('hidden');
// 	/* показываем толкьо первый таб */
// 	$('#b-tabs .b-tabs__content').first().removeClass('hidden');


// 	$(document).on('click', id_tab + ' ul.b-tabs__list li', function (event) {
// 		event.preventDefault(); /* Запрещаем переход по ссылке */
// 		var act_tab = $(this).children('a').attr('href'); /* Получаем href таба */

// 		/* Тоже самое только с классами */
// 		$('#b-tabs .b-tabs__content').addClass('hidden'); /* Скрываем все табы */
// 		$(act_tab).removeClass('hidden'); /* Показываем 1 таб, у которого id = href */

// 	});
// }
