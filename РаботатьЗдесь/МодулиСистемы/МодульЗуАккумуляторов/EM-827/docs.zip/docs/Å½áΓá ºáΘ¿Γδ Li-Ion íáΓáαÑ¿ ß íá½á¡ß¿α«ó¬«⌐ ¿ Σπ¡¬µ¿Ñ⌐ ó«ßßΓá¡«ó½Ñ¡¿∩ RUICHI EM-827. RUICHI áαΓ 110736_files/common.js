$(document).ready(function () {
  var debug = true;

  InitComponents();


  //
  // функции
  //

  /*
  *   Внимание! Все доп. скрипты/плагины лучше подгружать с помощью CheckAndLoadFunction(...)
  *   Это нужно для того, чтобы сайт не засирался лишнимы скриптами и они подгружались только когда реально нужны
  */


  //Инициализация data-component элементов
  function InitComponents () {
    var componentsList = {
      'ajax-news-loader': InitAjaxNewsLoader, //ajax-подгрузка новостей
      'category-product-popup': InitCategoryProductPopup, //poup-информация о товаре
      'form-search-header': InitFormSearchHeader, //форма поиска в шапке
      'form-select': InitFormSelect,  //стилизованный select
      'form-invert-spoiler': InitFormInvertSpoiler,  //открыть-свернуть форму поиска
      'lazy': InitLazy, //lazy-загрузка картинок
      'menu-make-bullets': InitMenuMakeBullets, //добавить буллеты в меню (из-за специфики дизайна через css нереализуемо)
      'menu-mobile': InitMenuMobile,  //мобильное меню
      'redirect-by-select': InitRedirectBySelect, //редирект в зависимости от выбранного значения поля select
      'remove-hidden-class': InitRemoveHiddenClass, //удалить класс "hidden" у цели по клику
      'slider-history': InitSliderHistory,  //слайдер "история" странице "О компании"
      'slider-main': InitSliderMain,  //слайдер на главной странице
      'slider-production': InitSliderProduction,  //слайдер с картинками на странице "О компании"
      'ajax-form': InitAjaxForm,  //ajax-отправка форм
      'ajax-popup-form': InitAjaxPopupForm, //ajax-popup-формы (fancybox)
      //'input-phone-mask': InitInputPhoneMask,   //поле ввода телефона
    };

    $.event.special.destroyed = {
      remove: function (o) {
        if (o.handler && o.type !== 'destroyed') {
          o.handler();
        }
      }
    };

    $(document).on('document:request-alter', function () {
      for (var name in componentsList) {
        $('[data-component="' + name + '"]').each(function () {
          $(this)
            .removeAttr('data-component')
            .attr(
              'data-component-active',
              name + (debug
                ? ' => components.js:' + componentsList[name].name + '()'
                : ''
              )
            );
          componentsList[name]($(this));
        });
      }
    });

    $(document).trigger('document:request-alter');
    InitDOMObserver();
  }


  //Отслеживание изменений DOM и реинициализация компонент если требуется
  function InitDOMObserver () {
    var timer = false;
    var reinitializationDelay = 100; //ms

    var ReinitializeComponents = function () {
      timer = false;
      $(document).trigger('document:request-alter');
    };

    //таймер здесь нужен чтобы не запускать инициализацию на каждый чих.
    //при изменении DOM в последующие 100мс любые события игнорируются, и только потом запускается инициализация всех появившихся компонент
    var OnChange = function (mutation) {
      if (timer !== false) {
        return;
      }

      timer = setTimeout(ReinitializeComponents, reinitializationDelay);
    };

    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(OnChange);
    });

    var config = {
      attributes: false,
      childList: true,
      characterData: false,
      subtree: true
    };

    observer.observe($('body').get(0), config);
  };


  //
  //
  //


  function CheckAndLoadFunction (func, scriptUrl, callback) {
    if (typeof func === 'function') {
      return callback();
    }

    $.getScript(scriptUrl, callback);
  };


  function InitMenuMakeBullets ($node) {
    $node.find('ul:first > li').each(function () {
      $(this).after($('<li>').addClass('bullet'));
    });
  }


  function InitSliderMain ($node) {
    var slidesCount = $node.find('.swiper-slide').length;
    if (slidesCount < 2) {
      return;
    }

    CheckAndLoadFunction(window.Swiper, '/catalog/view/javascript/swiper.min.js', function () {
      var slider = new Swiper($node.get(0), {
        slidesPerView: 1,
        spaceBetween: 30,
        preloadImages: false,
        lazy: true,
        autoplay: {
          delay: 4000
        },
        on: {
          init: function () {
            this.update();
          }
        }
      });
    });
  }


  function InitLazy ($node) {
    var $lazy = $node.find('.lazy');
    if (!$lazy.length) {
      return;
    }

    $lazy.Lazy();
  }


  function InitRemoveHiddenClass ($node) {
    $node.on('click', function () {
      var $this = $(this);
      var $target = $($this.data('target'));
      $target.removeClass('hidden hidden-tablet');
      $this.remove();
      return false;
    });
  }


  function InitAjaxForm ($node) {
    CheckAndLoadFunction($.fn.ajaxSubmit, '/catalog/view/javascript/jquery.form.js', function () {
      var $form = ($node.get(0).tagName === 'FORM' ? $node : $node.find('form'));

      $form.on('submit', function () {
        var $this = $(this);
        $this.find('[data-type="alert"]').removeClass('form-error form-success').html('');
        var formData = $this.serializeArray();
        var valuesList = {};





        formData.forEach(function (item) {
          valuesList[item.name] = item.value;
        });
        $this.ajaxSubmit({
          success: function (res) {
            var success = res.success || false;
            var js_success = $node.data('js-success') || '';

            if (success && js_success.length) {
              eval(js_success);
            }

            if (typeof res.redirect === 'string') {
              location.href = res.redirect;
              return false;
            }

            if (typeof res.content === 'string') {
              $this.html(res.content);

              // if($('.form-partnership-wrapper')){
              //
              // }

              var styleElem = document.head.appendChild(document.createElement("style"));
              styleElem.innerHTML = ".form-wrapper.form-partnership-wrapper:before {height: 220px;}";

              var styleElem = document.head.appendChild(document.createElement("style"));
              styleElem.innerHTML = ".form-wrapper:before {height: 220px;}";

            } else if (typeof res === 'string') {
              $this.html(res);
            }

            var $alert = $this.find('[data-type="alert"]');
            var alertText = res.alert || false;
            if (alertText !== false) {
              $alert.html(alertText);
              $alert.addClass('form-error');
            }
            /* $('body, html').stop().animate({
              scrollTop: $this.offset().top - 80
            }); */
          }
        });

        return false;
      });
    });
  }


  function InitAjaxPopupForm ($node) {

    var attr = {};

    attr.formUrl = $node.data('url') || false; //url скрипта вывода формы
    attr.formName = $node.data('name') || false; //название товара
    attr.formSku = $node.data('sku') || false; //название товара
    attr.autoOpen = $node.data('auto-open') || false; //автоматически вывести форму сразу после загрузки страницы


    $node.on('click', function() {
      var self = this;
      var isDisabled = self.__is_disabled || false;

      if (isDisabled) {
        return false;
      }
      self.__is_disabled = true;

      $.get(attr.formUrl, attr).done(function(res) {
        var content = typeof res === 'string' ? res : res.content || '';
        var redirect = res.redirect || '';

        if (redirect.length) {
          location.href = redirect;
          return false;
        }


        CheckAndLoadFunction($.fn.fancybox, '/catalog/view/javascript/jquery.fancybox.min.js', function () {
          $.fancybox.defaults.btnTpl.close = '<button data-fancybox-close class="fancybox-button fancybox-button--close fancybox-button--close-custom" title="{{CLOSE}}">test</button>';
          $.fancybox.open(content, {
            baseClass: 'fancybox-container-big-close-button'
          });
        });
      }).always(function () {
        self.__is_disabled = false;
      });

      return false;
    });

    if (attr.autoOpen) {
      $node.trigger('click');
    }
  }


  function InitMenuMobile ($node) {
    var catalogMenu = $node.data('menu-catalog');
    var isCatalog = !!$node.data('is-catalog');
    $node.find('.catalog').addClass(isCatalog ? 'current' : '').each(function () {
      var $subMenu = $('<ul>').addClass('submenu');
      catalogMenu.forEach(function (item) {
        $subMenu.append(
          $('<li>').addClass(item.is_current ? 'current' : '').append(
            $('<a>').attr('href', item.url).text(item.name)
          )
        );
      });
      $(this).append($subMenu);
    });

    $node.on('click', '[data-type="menu-toggle"]', function () {
      $node.toggleClass('active');
      $('body').toggleClass('mobile-menu');
    });

    $node.on('click', 'ul > li', function () {
      if (!IsMobileViewport()) {
        return;
      }
      var $this = $(this);
      var $subMenu = $this.find('.submenu');
      var hasSubmenu = $subMenu.length;
      if (hasSubmenu) {
        $this.toggleClass('active');
        $subMenu.slideToggle({
          duration: 100,
          easing: 'linear'
        });
        if ($this.hasClass('active')) {
          return false;
        }
      }
    });
  }


  function InitSliderProduction ($node) {
    CheckAndLoadFunction(window.Swiper, '/catalog/view/javascript/swiper.min.js', function () {
      var slidesCountStr = $node.find('.swiper-slide').length.toString().replace(/^([0-9])$/, '0$1');

      $node.find('.swiper-wrapper').after('\
        <div class="swiper-pagination">\
          <div class="numbers">\
            <div class="active"></div>\
          </div>\
          <div class="swiper-button-prev"></div>\
          <div class="swiper-button-next"></div>\
        </div>\
      ');

      var UpdateNumbers = function (slider) {
        var currentIndex = (slider.realIndex + 1).toString().replace(/^([0-9])$/, '0$1');
        $node.find('.numbers').text(' / ' + slidesCountStr).prepend($('<div>').addClass('active').text(currentIndex));
      };

      var slider = new Swiper($node.get(0), {
        slidesPerView: 1,
        spaceBetween: 10,
        preloadImages: false,
        lazy: true,
        autoplay: {
          delay: 4000
        },
        navigation: {
          prevEl: $node.find('.swiper-pagination .swiper-button-prev').get(0),
          nextEl: $node.find('.swiper-pagination .swiper-button-next').get(0)
        },
        on: {
          init: function (slider) {
            this.update();
            UpdateNumbers(slider);
          },
          slideChange: UpdateNumbers
        }
      });
    });
  }


  function InitSliderHistory ($node) {
    CheckAndLoadFunction(window.Swiper, '/catalog/view/javascript/swiper.min.js', function () {
      var slides = [];
      $node.find('table tr').each(function () {
        var $this = $(this);
        slides.push({
          year: $this.find('td:eq(0)').text().replace(/^\s+|\s+$/, ''),
          text: $this.find('td:eq(1)').text().replace(/^\s+|\s+$/, '')
        });
      });
      slides.reverse();
      $node.find('table').remove();
      $node.append('\
        <div class="swiper-container-wrapper--about-history">\
          <div class="swiper-container swiper-container--about-history">\
            <div class="swiper-wrapper">\
            </div>\
          </div>\
          <div class="swiper-history-pagination">\
            <div class="swiper-button-prev"></div>\
            <div class="swiper-button-next"></div>\
          </div>\
        </div>\
      ');

      var $wrapper = $node.find('.swiper-wrapper');
      slides.forEach(function (slide) {
        $wrapper.prepend($('\
          <div class="swiper-slide">\
            <div class="year">' + slide.year + '</div>\
            <div class="text">' + slide.text + '</div>\
          </div>\
        '));
      });

      const slider = new Swiper($node.find('.swiper-container').get(0), {
        slidesPerView: 'auto',
        spaceBetween: 0,
        navigation: {
          prevEl: $node.find('.swiper-history-pagination .swiper-button-prev').get(0),
          nextEl: $node.find('.swiper-history-pagination .swiper-button-next').get(0)
        },
        on: {
          init: function (slider) {
            this.update();
          }
        }
      });
    });
  }


  function InitAjaxNewsLoader ($node) {
    $node.on('click', function () {
      $node.addClass('disabled');
      var url = $node.data('url');
      var target = $node.data('target');
      $.get(url, function (res) {
        var $itemsList = $(res).find(target).find('> *');
        var $pagination = $(res).find('[data-type="news-list-pagination"]');
        $(target).append($itemsList);
        $node.after($pagination).remove();
      });
    });
  }


  function InitFormSelect ($node) {
    CheckAndLoadFunction($.fn.niceSelect, '/catalog/view/javascript/jquery/nice-select/jquery.nice-select.js', function () {
      $node.niceSelect();
      CheckAndLoadFunction(window.SimpleScrollbar, '/catalog/view/javascript/jquery/simple-scrollbar/simple-scrollbar.js', function () {
        $node.next().on('open.nice_select', function () {
          var $list = $node.next().find('.list');
          $list.attr('ss-container', '');
          SimpleScrollbar.initAll();
        });
      });
    });
  }

  function IsTouchDevice () {
    return (
      ('ontouchstart' in window)
      || (navigator.maxTouchPoints > 0)
      || (navigator.msMaxTouchPoints > 0)
    );
  }


  function InitRedirectBySelect ($node) {
    $node.on('change', 'select', function () {
      window.location = $(this).val();
    });
  }


  function IsMobileViewport () {
    return ($(window).width() < 768);
  }


  function InitFormSearchHeader ($node) {
    CheckAndLoadFunction($.fn.autocomplete, '/catalog/view/javascript/jquery/autocomplete/jquery.autocomplete.js', function () {
      $node.find('input[type="text"]').autocomplete({
        minChars: 2,
        serviceUrl: 'index.php?route=product/live_search',
        paramName: 'filter_name',
        deferRequestBy: 100,
        maxHeight: 480,
        transformResult: function (res) {
          var res = JSON.parse(res);
          return {
            suggestions: $.merge(
              $.map(res.products || [], function (item) {
                return {
                  value: item.name,
                  data: (item.url_section.length ? item.url_section : item.url)
                };
              }),
              $.map(res.sections || [], function (item) {
                return {
                  value: item.name,
                  data: item.url
                };
              })
            )
          };
        },
        onSearchComplete: function () {
          if (!IsMobileViewport()) {
            CheckAndLoadFunction($.fn.customScrollbar, '/catalog/view/javascript/jquery/jquery.custom-scrollbar.min.js', function () {
              setTimeout(function () {
                $('.autocomplete-suggestions').css({height: '100%'}).customScrollbar();
              }, 100);
            });
          }
          /*
          CheckAndLoadFunction(window.SimpleScrollbar, '/catalog/view/javascript/jquery/simple-scrollbar/simple-scrollbar.js', function () {
            $('.autocomplete-suggestions').removeClass('ss-container');
            $('.autocomplete-suggestions').attr('ss-container', '');
            var obj = $('.autocomplete-suggestions').get(0);
            //Object.defineProperty(obj, 'data-simple-scrollbar', { needToRecreate: true });
            setTimeout(function () {
              //SimpleScrollbar.initAll();
              SimpleScrollbar.initEl(obj, true);
              setTimeout(function () {
                $('.autocomplete-suggestions .ss-content').trigger('scroll');
              }, 1);
            }, 100);
          });
          */
        },
        onSelect: function (item) {
          window.location = item.data;
        }
      });
    });
  }


  function InitFormInvertSpoiler ($node) {
    var textOpened = $node.text();
    var textClosed = $node.data('text');
    $node.on('click', function () {
      $node.toggleClass('active').closest('form').toggleClass('hidden');
      $node.text($node.hasClass('active') ? textClosed : textOpened);
      return false;
    });
  }


  function InitCategoryProductPopup ($node) {
    var OnHide = function () {
      $node.trigger('click');
    };

    $node.on('click', function () {
      var isInitialized = $node.data('is-initialized') || false;
      var $popup = $node.closest('.category-products-chars-popup');
      var $inner = $popup.find('> .inner');
      var height = $popup.find('[data-type="wrapper"]').height();
      $popup.toggleClass('active');
      $inner.height(height);

      if ($popup.hasClass('active')) {
        $(document).on('keyup', OnHide);
      } else {
        $(document).off('keyup', OnHide);
      }

      if (!isInitialized) {
        $node.data('is-initialized', true);
        $popup.on('click', '[data-type="close"], > .layout', OnHide);
      }

      return false;
    });
  }

  ////////viewed products
  $(document).on('click', '.js-quick-viewed', function (e) {
    //alert('test');
    var $this = $(this);
    if ($(e.target).is('a[href]') || $(e.target).closest('a').is('a[href]') || $(e.target).is('button') || $(e.target).closest('button').length) {
      return;
    }
    if (!$(e.target).closest('.popup-content').length || $(e.target).hasClass('close')) {
      $this.find('.popup').toggleClass('visible');
    }
    $('.product_quick_view_button--active').remove();
    var pop = $this.find('.popup');
    var el = $this.closest('.product_quick_view_button');
    el = el[0].cloneNode( true );
    $(el).addClass('product_quick_view_button--active');
    //el.addClass('remove_btn')
    var parent = $('.wrap-viewed');
    parent[0].appendChild(el);
    pop.removeClass('visible');
    var child = parent.children('.product_quick_view_button');

    child.css({'border': 'none'}).addClass('remove_child')
    $(child).html($(child).children())
    //parent.find('.product_quick_view_button')[0].css({'border': 'none'})
    return false;
  });

  $('body').on('click','.close', function (e) {
    var parent = $('.wrap-viewed');
    parent.children('.remove_child').remove();

  });
////////end  viewed products


});
