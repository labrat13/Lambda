function FetchObject(A) {
	if (document.getElementById) {
		return document.getElementById(A)
	} else {
		if (document.all) {
			return document.all[A]
		} else {
			if (document.layers) { return document.layers[A] }
			else { return null }
		}
	}
}

function ToggleCollapse(A) {
	var D = FetchObject("collapseobj_" + A);
	var B = FetchObject("collapseimg_" + A);
	var C = FetchObject("collapsecel_" + A);

	if (!D) { if (B) { B.style.display = "none" } return false }
	if (D.style.display == "none") {
		D.style.display = "";
		if (B) {
			img_re = new RegExp("_closed\\.gif$");
			B.src = B.src.replace(img_re, "_opened.gif")
		}
		if (C) {
			cel_re = new RegExp("^(thead|tcat)(_closed)$");
			C.className = C.className.replace(cel_re, "$1")
		}
	} else {
		if (D.style.display != "none") {
			D.style.display = "none";
			if (B) {
				img_re = new RegExp("_opened\\.gif$");
				B.src = B.src.replace(img_re, "_closed.gif")
			}
			if (C) {
				cel_re = new RegExp("^(thead|tcat)$");
				C.className = C.className.replace(cel_re, "$1_collapsed")
			}
		}
	}
	return false
}